/**
 * 
 */

$(document).ready(function() {
	var table = $('#custom').DataTable( {
        "pagingType": "full_numbers"
    } );
});